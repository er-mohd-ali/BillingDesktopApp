package Billing_App;


import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.Statement;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author Mohammad_Ali
 */
public class DataBase {
    
   private static String url="jdbc:oracle:thin:@//localhost:1521/xe";
   private static String user="moto";
   private static String password="moto";
   private static Connection conn;
   private static Statement stm;
   public static Statement getStatement()
   {
       try{
           conn=DriverManager.getConnection(url,user,password);
           stm=conn.createStatement();
       }catch(SQLException e)
       {
           e.printStackTrace();
       }
       
       return stm;
   }
}
